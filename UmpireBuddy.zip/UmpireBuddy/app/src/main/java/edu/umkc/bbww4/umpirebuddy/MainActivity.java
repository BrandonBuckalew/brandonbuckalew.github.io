package edu.umkc.bbww4.umpirebuddy;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ActionMode;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    public final static String EXTRA_DATA = "edu.umkc.bbww4.umpirebuddy.ABOUTDATA";
    private final static String TAG = "Umpire Buddy";
    private final static String PREFS_NAME = "PrefsFile";

    private int strike_count = 0;
    private int ball_count = 0;
    private int out_count = 0;

    private ActionMode mActionMode;

    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback(){

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu){
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.context_menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false; // Return false if nothing is done
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.contextStrike:
                    if (strike_count == 2){
                        strike_count++;
                        updateStrikeCount();
                        alert_strike();
                    }
                    else if (strike_count <3){
                        strike_count++;
                        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putInt("strike_count", strike_count);
                        editor.commit();
                        updateStrikeCount();
                    }
                    else{
                    }
                    mode.finish(); // Action picked, so close the Contextual Action Bar(CAB)
                    return true;
                case R.id.contextBall:
                    if(ball_count == 3){
                        ball_count++;
                        updateBallCount();
                        alert_ball();
                    }
                    else if (ball_count <4){
                        ball_count++;
                        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putInt("ball_count", ball_count);
                        editor.commit();
                        updateBallCount();
                    }
                    else{
                    }
                    mode.finish(); // Action picked, so close the CAB
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //The following will print to LogCat.
        Log.i(TAG, "Starting onCreate...");
        setContentView(R.layout.activity_main);


        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        strike_count = settings.getInt("strike_count", strike_count);
        ball_count = settings.getInt("ball_count", ball_count);
        out_count = settings.getInt("out_count", out_count);
        updateStrikeCount();
        updateBallCount();
        updateOutCount();

        if (savedInstanceState != null) {
            out_count = savedInstanceState.getInt("out_count");
        }

        LinearLayout layout = (LinearLayout) findViewById(R.id.linear_layout);
        layout.setOnLongClickListener(new View.OnLongClickListener() {
            // Called when the user long-clicks on someView
            public boolean onLongClick(View view) {
                // mActionMode is set back to null
                //    above when the context menu disappears.
                if (mActionMode != null) {
                    return false;
                }

                // Start the CAB using the ActionMode.Callback defined above
                mActionMode = startActionMode(mActionModeCallback);
                view.setSelected(true);
                return true;
            }
        });

        View strikeButton = findViewById(R.id.strike_button);
        // This class implements the onClickListener interface.
        // Passing 'this' to setOnClickListener means the
        //   onClick method in this class will get called
        //   when the button is clicked.
        strikeButton.setOnClickListener(this);
        updateStrikeCount();

        View ballButton = findViewById(R.id.ball_button);
        ballButton.setOnClickListener(this);
        updateBallCount();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void updateStrikeCount() {
        TextView t = (TextView)findViewById(R.id.strike_value);
        t.setText(Integer.toString(strike_count));
    }

    private void updateBallCount() {
        TextView t = (TextView)findViewById(R.id.ball_value);
        t.setText(Integer.toString(ball_count));
    }

    private void updateOutCount() {
        TextView t = (TextView)findViewById(R.id.out_value);
        t.setText(Integer.toString(out_count));
    }

    private void alert_strike(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this, AlertDialog.THEME_TRADITIONAL);
        //builder.setTitle("Dialog box");
        builder.setMessage("Out!");
        builder.setCancelable(false);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                strike_count = 0;
                ball_count = 0;
                out_count++;
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putInt("strike_count", strike_count);
                editor.putInt("ball_count", ball_count);
                editor.putInt("out_count", out_count);
                editor.commit();
                // Note, you have to call update count here because.
                //   the call builder.show() below is non blocking.
                updateStrikeCount();
                updateBallCount();
                updateOutCount();
            }
        });
        builder.show();

    }

    private void alert_ball(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this, AlertDialog.THEME_TRADITIONAL);
        //builder.setTitle("Dialog box");
        builder.setMessage("Walk!");
        builder.setCancelable(false);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                strike_count = 0;
                ball_count = 0;
                SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putInt("strike_count", strike_count);
                editor.putInt("ball_count", ball_count);
                editor.commit();

                // Note, you have to call update count here because.
                //   the call builder.show() below is non blocking.
                updateStrikeCount();
                updateBallCount();
            }
        });
        builder.show();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.strike_button:
                if (strike_count == 2){
                    strike_count++;
                    updateStrikeCount();
                    alert_strike();
                }
                else if (strike_count <3){
                    strike_count++;
                    SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                    SharedPreferences.Editor editor = settings.edit();
                    editor.putInt("strike_count", strike_count);
                    editor.commit();
                    updateStrikeCount();
                }
                else{
                    //Don't do anything
                }
                break;
            case R.id.ball_button:
                if(ball_count == 3){
                    ball_count++;
                    updateBallCount();
                    alert_ball();
                }
                else if (ball_count <4){
                    ball_count++;
                    SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                    SharedPreferences.Editor editor = settings.edit();
                    editor.putInt("ball_count", ball_count);
                    editor.commit();
                    updateBallCount();
                }
                else{
                    //Don't do anything
                }
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {
            case R.id.reset:
                strike_count = 0;
                updateStrikeCount();
                ball_count = 0;
                updateBallCount();
                return true;
            case R.id.about:
                Intent intent = new Intent(this, AboutActivity.class);
                intent.putExtra(EXTRA_DATA, "extra data or parameter you want to pass to activity");
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Lifecycle methods follow

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "onStart()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "onResume()");
    }

    // Note that onDestroy() may not be called if
    // the need for RAM is urgent (e.g., an incoming
    // phone call), but the activity will still be
    // shut down. Consequently, it's a good idea
    // to save state that needs to persist between
    // sessions in onPause().
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop()");
    }

    // Note that onDestroy() may not be called if
    // the need for RAM is urgent (e.g., an incoming
    // phone call), but the activity will still be
    // shut down. Consequently, it's a good idea
    // to save state that needs to persist between
    // sessions in onPause().
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy()");
    }

    // "icicle" is sometimes used as the name of the
    // parameter because onSaveInstanceState() used to
    // be called onFreeze().
    // The Bundle updated here is the same one passed
    //   to onCreate() above.
    // This method isn't guaranteed to be called. If it
    //   is critical that data be saved, save it in
    //   persistent storage in onPause() rather than here
    //   because this method will not be called in every
    //   situation as described in its documentation.
    // Summary: save data that should persist while the
    //   application is running here. Save data that should
    //   persist between application runs in persistent storage.
    @Override
    protected void onSaveInstanceState(Bundle icicle) {
        super.onSaveInstanceState(icicle);
        Log.i(TAG, "onSaveInstanceState()");
        icicle.putInt("out_count", out_count);
    }

    // Note, by convention most apps restore state in onCreate()
    // This method isn't used often.
    @Override
    protected void onRestoreInstanceState(Bundle icicle) {
        super.onRestoreInstanceState(icicle);
        Log.i(TAG, "onRestoreInstanceState()");
    }

}
