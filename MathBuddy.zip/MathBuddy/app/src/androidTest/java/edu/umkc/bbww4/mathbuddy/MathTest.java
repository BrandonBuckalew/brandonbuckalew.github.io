package edu.umkc.bbww4.mathbuddy;

import android.test.AndroidTestCase;

public class MathTest extends AndroidTestCase {
    private Math math;

    public void setUp(){
        math = new Math();
    }

    public void tearDown(){
        math = null;
    }

    public void testAddition() throws Exception{
        assertEquals("Addition gives wrong value!", 4, math.addition(2,2));
    }

    public void testSubtraction() throws Exception{
        assertEquals("Subtraction gives wrong value!", 0, math.subtraction(2, 2));
    }

    public void testMultiplication() throws Exception{
        assertEquals("Multiplication gives wrong value!", 4, math.multiplication(2, 2));
    }

    public void testDivision() throws Exception{
        assertEquals("Division gives wrong value!", 1, math.division(2,2));
    }
}
