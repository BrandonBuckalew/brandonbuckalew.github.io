package edu.umkc.bbww4.mathbuddy;

public class Math {
    private int answer;

    public int addition(int firstInt, int secondInt){
        answer = firstInt+secondInt;
        return answer;
    }

    public int subtraction(int firstInt, int secondInt){
        answer = firstInt-secondInt;
        return answer;
    }

    public int multiplication(int firstInt, int secondInt){
        answer = firstInt*secondInt;
        return answer;
    }

    public int division(int firstInt, int secondInt){
        answer = firstInt/secondInt;
        return answer;
    }
}