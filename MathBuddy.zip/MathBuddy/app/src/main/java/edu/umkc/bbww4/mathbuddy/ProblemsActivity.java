package edu.umkc.bbww4.mathbuddy;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class ProblemsActivity extends AppCompatActivity {
    private Math math = new Math();
    private final static String PREFS_NAME = "PrefsFile";
    private String mathType;
    private int maxNum;
    private int numProbs;
    private int firstInt;
    private int secondInt;
    private int lastFirstInt;
    private int lastSecondInt;
    private int answer;
    private int correctAnswers;
    private int problemCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problems);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        mathType = settings.getString("mathType", mathType);
        maxNum = settings.getInt("maxNum", maxNum);
        numProbs = settings.getInt("numProbs", numProbs);
        correctAnswers = 0;
        problemCounter = 0;
        lastFirstInt = 0;
        lastSecondInt = 0;
        editor.putInt("correctAnswers", correctAnswers);
        editor.putInt("problemCounter", problemCounter);
        editor.putInt("lastFirstInt", lastFirstInt);
        editor.putInt("lastSecondInt", lastSecondInt);
        editor.commit();
        //Try Catch for invalid option
        try {
            generateProblem();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void back2Main(View view) {
        Intent startNewActivity = new Intent(this, MainActivity.class);
        startActivity(startNewActivity);
    }

    private void alert_finished(){
        float fCorrectAnswers = (float)correctAnswers;
        float fProblemCounter = (float)problemCounter;
        AlertDialog.Builder builder = new AlertDialog.Builder(this, AlertDialog.THEME_TRADITIONAL);
        //builder.setTitle("Dialog box");
        builder.setMessage("You've finished all of the problems!" + "\n"
                + "Correct: " + correctAnswers + "\n"
                + "Incorrect: " + (problemCounter-correctAnswers) + "\n"
                + "Percentage: " + String.format(java.util.Locale.US,"%.0f",(fCorrectAnswers/fProblemCounter)*100) + "%");
        builder.setCancelable(false);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.show();
    }

    //Throws invalid option exception
    public void generateProblem() throws IOException {
        TextView tV1 = (TextView)findViewById(R.id.problem);
        TextView tV2 = (TextView)findViewById(R.id.answerChecker);
        if(problemCounter == numProbs){
            alert_finished();
        }
        else if(tV2.getText().toString().equals("") && problemCounter != 0){
            //Don't do anything. This means the user hasn't checked the problem first
            //Had to check that problemCounter wasn't equal to 0 or it would never show the first problem
            //This could either throw off the correctAnswers because it never got checked or move on without answering the problem
        }
        else {
            Button checkAnswer = (Button)findViewById(R.id.checkAnswer);
            checkAnswer.setEnabled(true);
            Button nextQuestion = (Button)findViewById(R.id.nextQuestion);
            nextQuestion.setEnabled(false);
            tV2.setText("");
            SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
            SharedPreferences.Editor editor = settings.edit();
            lastFirstInt = settings.getInt("lastFirstInt", lastFirstInt);
            lastSecondInt = settings.getInt("lastSecondInt", lastSecondInt);
            EditText t = (EditText)findViewById(R.id.answer);
            t.setText("");
            if (mathType.equals("Division")){
                do {
                    firstInt = new Random().nextInt(maxNum);
                    secondInt = new Random().nextInt(maxNum);
                }while((firstInt == 0 && secondInt == 0) || (firstInt == lastFirstInt && secondInt == lastSecondInt) || (secondInt == lastFirstInt && firstInt == lastSecondInt));
                checkOrderOfNumbers(firstInt, secondInt);
                divideEvenly(firstInt);
            }
            else {
                do {
                    firstInt = new Random().nextInt(maxNum);
                    secondInt = new Random().nextInt(maxNum);
                }while((firstInt == lastFirstInt && secondInt == lastSecondInt) || (secondInt == lastFirstInt && firstInt == lastSecondInt));
                checkOrderOfNumbers(firstInt, secondInt);
            }
            firstInt = settings.getInt("firstInt", firstInt);
            secondInt = settings.getInt("secondInt", secondInt);
            switch (mathType) {
                case "Addition":
                    answer = math.addition(firstInt, secondInt);
                    editor.putInt("answer", answer);
                    editor.commit();
                    tV1.setText(firstInt + " + " + secondInt + " = ?");
                    break;
                case "Subtraction":
                    answer = math.subtraction(firstInt, secondInt);
                    editor.putInt("answer", answer);
                    editor.commit();
                    tV1.setText(firstInt + " - " + secondInt + " = ?");
                    break;
                case "Multiplication":
                    answer = math.multiplication(firstInt, secondInt);
                    editor.putInt("answer", answer);
                    editor.commit();
                    tV1.setText(firstInt + " * " + secondInt + " = ?");
                    break;
                case "Division":
                    answer = math.division(firstInt, secondInt);
                    editor.putInt("answer", answer);
                    editor.commit();
                    tV1.setText(firstInt + " / " + secondInt + " = ?");
                    break;
                default:
                    //Assertion for Invalid Option
                    assert !true : "Invalid Option";
                    break;
            }
            problemCounter++;
            editor.putInt("problemCounter", problemCounter);
            lastFirstInt = settings.getInt("firstInt", firstInt);
            lastSecondInt = settings.getInt("secondInt", secondInt);
            editor.putInt("lastFirstInt", lastFirstInt);
            editor.putInt("lastSecondInt", lastSecondInt);
            editor.commit();
        }
    }

    //Throws Invalid Option Exception for generateProblem method
    public void generateProblem(View view) throws IOException {
        generateProblem();
    }

    public void checkAnswer(View view) {
        //Try Catch for Number Format Exception
        try {
            EditText t = (EditText) findViewById(R.id.answer);
            TextView tV = (TextView) findViewById(R.id.answerChecker);
            int tempAnswer;
            tempAnswer = Integer.parseInt(t.getText().toString());
            SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
            SharedPreferences.Editor editor = settings.edit();
            if (!tV.getText().toString().equals("")){
                //Don't do anything because that means it's already been checked.
            }
            else if (tempAnswer == answer) {
                Button checkAnswer = (Button)findViewById(R.id.checkAnswer);
                checkAnswer.setEnabled(false);
                Button nextQuestion = (Button)findViewById(R.id.nextQuestion);
                nextQuestion.setEnabled(true);
                tV.setText(tempAnswer + " is the correct answer!");
                correctAnswers++;
                editor.putInt("correctAnswers", correctAnswers);
                editor.commit();
            } else {
                Button checkAnswer = (Button)findViewById(R.id.checkAnswer);
                checkAnswer.setEnabled(false);
                Button nextQuestion = (Button)findViewById(R.id.nextQuestion);
                nextQuestion.setEnabled(true);
                tV.setText("The correct answer is " + answer + "!");
            }
        }
        catch (NumberFormatException e){}
    }

    private void checkOrderOfNumbers(int firstInt, int secondInt){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        if (mathType.equals("Division") && (firstInt == 0 || secondInt == 0)){
            if (firstInt == 0){
                editor.putInt("firstInt", firstInt);
                editor.putInt("secondInt", secondInt);
                editor.commit();
            }
            else{
                editor.putInt("firstInt", secondInt);
                editor.putInt("secondInt", firstInt);
                editor.commit();
            }
        }
        else if (firstInt >= secondInt){
            editor.putInt("firstInt", firstInt);
            editor.putInt("secondInt", secondInt);
            editor.commit();
        }
        else{
            editor.putInt("firstInt", secondInt);
            editor.putInt("secondInt", firstInt);
            editor.commit();
        }
    }

    private void divideEvenly(int firstInt){
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        ArrayList<Integer> factors = new ArrayList<>();
        if (firstInt == 0 || firstInt == 1){
            //Don't do anything because either the answer will always be 0. Ex. 0/5 = 0
            //or because 1 can only be divided by 1
        }
        else {
            for (int i = 1; i <= firstInt; i++) {
                if (firstInt % i == 0) {
                    factors.add(i);
                }
            }
            int numOfFactors = factors.size();
            int randomNum;
            int newInt;
            lastSecondInt = settings.getInt("lastSecondInt", lastSecondInt);
            if(numOfFactors <= 3) {
                do {
                    randomNum = new Random().nextInt(numOfFactors);
                    newInt = factors.get(randomNum);
                }while (newInt == lastSecondInt);
            }
            else{
                do{
                    randomNum = new Random().nextInt(numOfFactors);
                    System.out.println("Number of Factors: " + numOfFactors);
                    System.out.println("Random Number: " + randomNum);
                    System.out.println("--------------------------------");
                    newInt = factors.get(randomNum);
                }while (newInt == lastSecondInt || (randomNum == 0 || randomNum == numOfFactors-1));
            }
            editor.putInt("firstInt", firstInt);
            editor.putInt("secondInt", newInt);
            editor.commit();
        }
        factors.clear();
    }
}