package edu.umkc.bbww4.mathbuddy;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.content.SharedPreferences;

public class OptionsActivity extends AppCompatActivity {
    private final static String PREFS_NAME = "PrefsFile";
    private int maxNum = 5;
    private int numProbs = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SeekBar seekBar1 = (SeekBar)findViewById(R.id.numberOfProblemsSeekBar);
        SeekBar seekBar2 = (SeekBar)findViewById(R.id.maxNumberSeekBar);
        final TextView seekBarValue1 = (TextView)findViewById(R.id.numberOfProblemsTextView);
        final TextView seekBarValue2 = (TextView)findViewById(R.id.maxNumberTextView);

        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                seekBarValue1.setText(String.valueOf(progress+10));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });

        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                seekBarValue2.setText(String.valueOf((progress*5)+5));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });
    }

    public void problems(View view){
        updateMaxNum();
        updateNumProbs();
        Intent startNewActivity = new Intent(this, ProblemsActivity.class);
        startActivity(startNewActivity);
    }

    private void updateMaxNum(){
        TextView t = (TextView)findViewById(R.id.maxNumberTextView);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        //Try Catch for Number Format Exception
        try{
            maxNum = Integer.parseInt(t.getText().toString());
            editor.putInt("maxNum", maxNum);
            editor.commit();
        } catch (NumberFormatException e){
            maxNum = 0;
            editor.putInt("maxNum", maxNum);
            editor.commit();
        }
    }

    private void updateNumProbs(){
        TextView t = (TextView)findViewById(R.id.numberOfProblemsTextView);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        //Try Catch for Number Format Exception
        try{
            numProbs = Integer.parseInt(t.getText().toString());
            editor.putInt("numProbs", numProbs);
            editor.commit();
        } catch (NumberFormatException e){
            numProbs = 0;
            editor.putInt("numProbs", numProbs);
            editor.commit();
        }
    }
}
